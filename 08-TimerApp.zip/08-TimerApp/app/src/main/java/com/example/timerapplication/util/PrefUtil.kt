package com.example.timerapplication.util

import android.content.Context
import android.preference.PreferenceManager


class PrefUtil {
    // member defined in the companion object are like static objects
    companion object {
        fun getTimerLength(context: Context): Int{
            // placeholder
            return 1
        }

        private const val PREVIOUS_TIMER_LENGTH_ID = "com.example.timerapplication.previous_timer_length"

        fun getPreviousTimerLengthSeconds(context: Context): Long{
            val preferences = androidx. .getDefaultSharedPreferences(context)
            return preferences.getLong(PREVIOUS_TIMER_LENGTH_ID, 0)
        }

        fun setPreviousTimerLengthSeconds(seconds: Long, context: Context){
            val editor = Pre
        }
    }
}